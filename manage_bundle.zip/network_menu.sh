#!/usr/bin/env bash
# shellcheck shell=bash

manage_menu_network_render() {
  return 0
}

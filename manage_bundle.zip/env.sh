#!/usr/bin/env bash
# shellcheck shell=bash

: "${MANAGE_MODULES_DIR:=/opt/manage}"
: "${MANAGE_MODULES_CORE_DIR:=${MANAGE_MODULES_DIR}/core}"
: "${MANAGE_MODULES_FEATURES_DIR:=${MANAGE_MODULES_DIR}/features}"
: "${MANAGE_MODULES_MENUS_DIR:=${MANAGE_MODULES_DIR}/menus}"
: "${MANAGE_MODULES_APP_DIR:=${MANAGE_MODULES_DIR}/app}"

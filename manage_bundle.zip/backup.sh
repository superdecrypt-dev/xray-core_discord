#!/usr/bin/env bash
# shellcheck shell=bash

manage_feature_backup_ready() {
  return 0
}

#!/usr/bin/env bash
# shellcheck shell=bash

manage_menu_domain_render() {
  return 0
}

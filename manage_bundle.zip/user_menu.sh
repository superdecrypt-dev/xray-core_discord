#!/usr/bin/env bash
# shellcheck shell=bash

manage_menu_user_render() {
  return 0
}

#!/usr/bin/env bash
# shellcheck shell=bash

manage_feature_users_ready() {
  return 0
}

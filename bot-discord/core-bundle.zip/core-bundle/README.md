# Bot Discord (Core Bundle)

Core scaffold bot Discord untuk operasional Xray.

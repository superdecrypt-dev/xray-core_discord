#!/usr/bin/env bash
set -euo pipefail
echo "[todo] stop dev processes."

#!/usr/bin/env bash
set -euo pipefail
echo "[todo] smoke test gateway/backend/bridge."

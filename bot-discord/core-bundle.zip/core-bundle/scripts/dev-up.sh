#!/usr/bin/env bash
set -euo pipefail
echo "[todo] start gateway-ts + backend-py in dev mode."

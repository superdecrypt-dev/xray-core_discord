#!/usr/bin/env bash
set -euo pipefail

echo '{"ok":false,"error":"not_implemented","message":"bridge/manage_api.sh belum diimplementasikan"}'
exit 0

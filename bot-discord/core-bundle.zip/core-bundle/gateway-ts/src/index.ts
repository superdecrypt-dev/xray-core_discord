import "dotenv/config";

console.log("[gateway-ts] scaffold ready.");
console.log("[gateway-ts] implement /panel + button/select/modal flow.");

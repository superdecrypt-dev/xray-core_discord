export function handleModal(customId: string, fields: Record<string, string>): { ok: boolean; customId: string } {
  return { ok: false, customId };
}

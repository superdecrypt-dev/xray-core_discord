export function handleSelect(customId: string, values: string[]): { ok: boolean; customId: string; values: string[] } {
  return { ok: false, customId, values };
}

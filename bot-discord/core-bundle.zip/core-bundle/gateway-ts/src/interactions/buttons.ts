export function handleButton(customId: string): { ok: boolean; customId: string } {
  return { ok: false, customId };
}

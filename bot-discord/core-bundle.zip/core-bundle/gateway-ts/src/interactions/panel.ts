export function panelCommandName(): string {
  return "panel";
}

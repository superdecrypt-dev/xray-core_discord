export function menu_2_userView(): string {
  return "menu_2_user";
}

export function main_menuView(): string {
  return "main_menu";
}

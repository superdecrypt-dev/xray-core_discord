export function menu_7_securityView(): string {
  return "menu_7_security";
}

export function menu_5_domainView(): string {
  return "menu_5_domain";
}

export function menu_6_speedtestView(): string {
  return "menu_6_speedtest";
}

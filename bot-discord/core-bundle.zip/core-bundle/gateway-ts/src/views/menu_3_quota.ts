export function menu_3_quotaView(): string {
  return "menu_3_quota";
}

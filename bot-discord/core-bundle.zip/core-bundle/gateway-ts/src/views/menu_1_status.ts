export function menu_1_statusView(): string {
  return "menu_1_status";
}

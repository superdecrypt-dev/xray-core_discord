export function menu_4_networkView(): string {
  return "menu_4_network";
}

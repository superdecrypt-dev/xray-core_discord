def non_empty(value: str) -> bool:
    return bool((value or "").strip())

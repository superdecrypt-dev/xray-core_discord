def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_7_security", "payload": payload, "message": "not implemented"}

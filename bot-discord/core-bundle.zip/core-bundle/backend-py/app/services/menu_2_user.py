def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_2_user", "payload": payload, "message": "not implemented"}

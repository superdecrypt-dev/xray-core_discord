def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_3_quota", "payload": payload, "message": "not implemented"}

def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_4_network", "payload": payload, "message": "not implemented"}

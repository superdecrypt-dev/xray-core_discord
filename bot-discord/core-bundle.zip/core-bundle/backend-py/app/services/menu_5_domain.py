def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_5_domain", "payload": payload, "message": "not implemented"}

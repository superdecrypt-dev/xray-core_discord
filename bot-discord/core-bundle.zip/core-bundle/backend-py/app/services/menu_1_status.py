def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_1_status", "payload": payload, "message": "not implemented"}

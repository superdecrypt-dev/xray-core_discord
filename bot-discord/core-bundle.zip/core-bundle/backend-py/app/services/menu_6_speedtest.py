def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_6_speedtest", "payload": payload, "message": "not implemented"}

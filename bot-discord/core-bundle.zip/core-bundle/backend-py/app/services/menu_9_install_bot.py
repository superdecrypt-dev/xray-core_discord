def handle(payload: dict) -> dict:
    return {"ok": False, "service": "menu_9_install_bot", "payload": payload, "message": "not implemented"}

import { StringSelectMenuInteraction } from "discord.js";

export async function handleSelect(_interaction: StringSelectMenuInteraction): Promise<boolean> {
  // Placeholder: currently we use buttons + modals for most interactions.
  return false;
}
